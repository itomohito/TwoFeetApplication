package com.example.fitnessapp.adapter

data class ExerciseModel(
    var name: String,
    var time: String,
    var isDone : Boolean,
    var image: String
)
