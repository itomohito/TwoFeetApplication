package com.example.fitnessapp.adapter

data class DayModel(
    var exercises: String,
    var dayNumber: Int,
    var isDone : Boolean )
